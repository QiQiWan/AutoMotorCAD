# PyMotorCAD / Motor-CAD Mapping

Current target: **Motor-CAD 2026R1** with **ansys-motorcad-core 0.8.8**.

## Mapping authorities

- `motorcad_studio/config/solver_versions/2026R1/parameter_mapping.yaml`
- `motorcad_studio/config/solver_versions/2026R1/output_mapping.yaml`
- `motorcad_studio/config/solver_versions/2026R1/template_capabilities.yaml`
- `motorcad_studio/config/motorcad_native_binding.yaml`
- `motorcad_studio/config/native_closure_profiles.yaml`

The canonical Studio parameter/result IDs remain independent of raw Motor-CAD Automation names. Version-specific mappings translate between the two layers.

## Current parameter status

The core engineering parameter registry contains 43 parameters. Version-specific mappings are explicit; candidate-only mappings remain unqualified until a target Windows workstation confirms read/write/readback semantics. No missing mapping should be fabricated merely to make coverage appear complete.

## Current representative native profiles

The production qualification matrix uses:

- SPM — `i5_Industrial_SPM_Servo_Tooth_Wound`
- IPM — `e9_eMobility_IPM`
- AFPM — `e14_eMobility_AFM`
- IM — `i4_Industrial_IM`

Formal support requires native closure, binding readback, precheck, solve, result extraction/integrity, restart/reopen, license evidence and clean process exit.

## Version changes

When upgrading Motor-CAD or PyMotorCAD, create a new solver-version mapping set and re-run formal Windows qualification. Do not silently reuse the 2026R1 mapping as though it had already been qualified on a different release.
