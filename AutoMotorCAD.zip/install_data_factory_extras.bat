@echo off
setlocal
cd /d %~dp0
if not exist .venv\Scripts\python.exe (
  py -3 -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements-data.txt
if errorlevel 1 exit /b 1
echo Data Factory Parquet extras installed.
endlocal
