# MotorCAD Studio changelog

## 0.87.9 — Interaction Integrity & Automatic Self-check Progress
- Fixed whole-shell startup crash caused by legacy task-form DOM listeners after the clean-source consolidation.
- Delayed Engineer Journey refresh until the active project context has been validated; stale project IDs now self-invalidate without noisy 404 UI failures.
- Added automatic shallow environment self-check progress with explicit 0–100% stage feedback; deep Motor-CAD process validation remains manual.
- Added a full-shell browser simulation using the complete current `index.html` and all JavaScript assets, plus a product control-plane smoke chain across Design → Validate → Decide.

# Changelog

## 0.87.9 — Current Clean Release

- Consolidated the engineer workflow around **Design → Validate → Decide**.
- Retained SPM/IPM/AFPM Golden Motor Starters, canonical engineering parameter/result semantics, Standard Validation, Engineering Scorecard, Parameter Study and Optimization Decision Workbench.
- Retained Runtime Lifecycle Qualification, Windows Production Qualification and 100/500 Case Production Soak authorities.
- Cleaned the source distribution: removed historical release notes, archived static snapshots, sample outputs, obsolete Windows runners, pre-current verification scripts and historical test archives.
- Replaced version-numbered operator runner names with stable production names.
- Reduced the shipped test suite to current release/core qualification tests.
- Formal Windows + licensed Motor-CAD 2026R1 qualification remains fail-closed until native workstation evidence is completed.
