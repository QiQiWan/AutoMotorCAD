# Current Release Test Report

Release: **MotorCAD Studio 0.87.9 / Schema 44**

## Interaction-integrity repair

The 0.87.8 clean-source consolidation exposed a whole-shell startup defect: legacy task-form DOM nodes were removed from `index.html`, while `app.js` still bound listeners to those nodes during bootstrap. The first missing `#templateSelect` listener aborted `app.js`, which prevented most subsequent UI initialization.

0.87.9 repairs the startup contract and adds regression coverage for this class of defect:

- all retired legacy task-form bindings used during bootstrap are optional;
- `EngineerJourney` waits for `mcs:bootstrap-ready` before reading project context;
- stale persisted project IDs self-invalidate instead of repeatedly issuing 404 journey requests;
- startup automatically performs the shallow environment self-check with an explicit 0–100% progress indicator;
- the deep Motor-CAD check remains manual because it launches Motor-CAD and may consume a license;
- the browser regression now loads the **complete current `index.html` plus all 75 current JavaScript assets** rather than only isolated feature fragments.

## Global operation simulation

A new whole-product smoke chain exercises the current control plane in sequence:

`Startup → Runtime setup → Project creation → Golden SPM design → Design Revision → Standard Validation preview/materialization → Analysis Definition → Optimization Catalog → Engineering Scorecard → Results Workbench`.

A new full-shell Chromium simulation additionally exercises:

- automatic startup shallow self-check and progress completion;
- stale local project-context cleanup;
- Project / Runtime / Problems / Advanced Tools top-level navigation;
- project creation and entry;
- routed **Design → Validate → Decide** stage mounting;
- all current JavaScript assets loaded together with zero page errors and zero console errors.

## Current backend/product regression

Current backend/product qualification files were executed in isolated pytest processes to avoid the known historical module-level TestClient teardown coupling.

- Core API: 2/2 PASS
- MTT parser: 2/2 PASS
- Canonical project-flow UI contract: 5/5 PASS
- Global product control-plane + startup contract: 2/2 PASS
- Guided Golden Motor Starters: 4/4 PASS
- Engineering semantics + Standard Validation: 5/5 PASS
- Parameter Study + Optimization Decision: 5/5 PASS
- Runtime Lifecycle Qualification: 10/10 PASS
- Windows Production Qualification contract: 9/9 PASS
- Production Soak Hardening contract: 8/8 PASS
- **Backend/current product total: 52/52 PASS**

Pytest collection: **52/61 selected; 9 browser E2E tests deselected by the default marker policy; 0 collection errors.**

## Current Chromium HMI regression

- Full current shell / all-current-JS interaction simulation: 1/1 PASS
- Guided Golden Motor Starter HMI: 1/1 PASS
- Optimization Decision Workbench HMI: 2/2 PASS
- Production Soak HMI: 1/1 PASS
- Runtime Lifecycle HMI: 1/1 PASS
- Standard Validation + Scorecard HMI: 2/2 PASS
- Windows Production Qualification HMI: 1/1 PASS
- **Current Chromium HMI total: 9/9 PASS**

## Static/package verification

- Python compile: PASS
- Active frontend: 75 JavaScript / 7 CSS
- JavaScript syntax: 75/75 PASS
- Active `index.html` static references: current version only
- Clean-source single-authority contract: PASS
- Neutral wheel build/install: PASS
- Wheel version: 0.87.9
- Wheel package data: 32 YAML / 33 MTT / 75 JS / 7 CSS
- Automatic self-check progress DOM included in wheel: PASS
- Wheel console entry points: `motorcad-studio`, `motorcad-studio-windows-qualification`, `motorcad-studio-production-soak`

## Production boundary

The global operation simulation proves the Studio control plane and HMI can complete their current product workflows with controlled/mocked solver responses. It does **not** replace formal native execution evidence.

Formal **Windows + licensed Motor-CAD 2026R1** qualification and formal **100/500 native Case soak** remain **PENDING** until executed on a qualified workstation. Local/CI evidence cannot promote those gates.
